const layoutTypes = {
	SET_ITEM_OPEN: 'SET_ITEM_OPEN',
	SET_ACTIVE_ROUTE: 'SET_ACTIVE_ROUTE',
};
export default layoutTypes;
