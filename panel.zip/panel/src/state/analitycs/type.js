import { ApiRequestActionTypes } from '../../common/utils';

const analyticsTypes = {
	GET_ANALYTICS: new ApiRequestActionTypes('GET_ANALYTICS'),
	GET_HOTS: new ApiRequestActionTypes('GET_HOTS'),
};
export default analyticsTypes;
