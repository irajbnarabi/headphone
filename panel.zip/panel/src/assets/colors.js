export const MainColor = '#ff005c';
