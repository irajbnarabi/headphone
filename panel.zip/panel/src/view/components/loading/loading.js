import CircularProgress from '@material-ui/core/CircularProgress';
import React from 'react';

export default function Loading() {
	return <CircularProgress />;
}
