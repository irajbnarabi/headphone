import './not-found.scss';
import React from 'react';
import Layout from '../../components/layout/Layout';

function NotFoundPage() {
	return <Layout>404</Layout>;
}

export default NotFoundPage;
