import './home.scss';
import React from 'react';
import Layout from '../../components/layout/Layout';

function HomePage() {
	return <Layout>Home</Layout>;
}

export default HomePage;
